1. 启动程序
    · 定位到项目中的 main.py文件。
   · 在命令行或终端中，进入该文件所在目录。
   · 输入命令python app.py并回车，即可启动程序。确保你的系统已正确安装Python且环境变量已配置好。
2. 运行程序与导入数据
   · 问题选择与数据规模设置
       · 程序启动后，界面上会呈现“Problem Selection”区域。
       · 点击下拉菜单，可在“Knapsack”（背包问题）和“TSP”（旅行商问题）之间选择问题类型。
       · 在“Data Size”输入框内，输入一个整数作为数据规模，比如输入“15”。
   · 生成数据
       · 完成上述设置后，点击“Generate Data”按钮。
       · 若输入合法，界面下方文本框会显示如“Generated data for Knapsack with size 15”（针对背包问题）或“Generated data for TSP with size 15”（针对旅行商问题）的提示。
       · 对于背包问题，可视化区域会展示物品价值的柱状图等相关数据图形；对于旅行商问题，会绘制城市坐标点。
   · 算法选择
       · 在“Algorithm Selection”区域，有多个算法选项，如“Backtracking”“Branch and Bound”“Genetic Algorithm”等。
       · 根据需求勾选想要运行的算法，可单选或多选。
   · 运行算法与查看结果
       · 点击“Run Algorithms”按钮，程序开始运行所选算法。
       · 运行结束后，每个算法的结果会在界面下方文本框依次显示。例如，遗传算法结果可能为“Genetic Algorithm: Size: 15, Best Value: 120.00, Time: 0.4500 s, Solution: Items selected: 1, 4, 6, 9, total items: 4”。
3. 环境要求
   · 编程语言及版本：使用Python编写，建议使用Python 3.x版本。
   · 第三方库
       · numpy：用于数值计算，如数组处理、数学运算等。
       · matplotlib：用于创建可视化图表，展示数据和算法结果。
       · tkinter：构建图形用户界面，实现交互操作。
       · logging：记录程序运行日志，辅助调试和错误追踪。

注意事项：
1.运行前确保已安装所需第三方库，可在命令行使用 pip install numpy matplotlib 等命令安装（依实际情况而定）。
2. 输入数据不合法时，程序会在界面提示错误，如输入非整数数据规模时会显示“Invalid size. Please enter an integer.”。
3.程序运行时，控制台会输出日志信息，包括程序运行状态、数据生成与算法执行详情、错误提示等，有助于调试与问题定位。